
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>REDSPORT | Just Dont Do It</title>
	<link href="{{ asset('css/styleshop.css') }}" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<img src="images/logo.png" width="175px">
			</div>
			<nav>
				<ul>
					<li><a href="{{route('MainPage')}}">Home</a></li>
					<li><a href="{{route('Shop')}}">Shop</a></li>
					<li><a href="{{route('Blog')}}">Blog</a></li>
					<li><a href="{{route('FAQ')}}">FAQ</a></li>
					<li><a href="{{route('About')}}">About</a></li>
					<li><a href="{{route('Contact')}}">Contact</a></li>
					<li><a href="{{route('login')}}" id="a">Log In</a></li>
				</ul>
			</nav>

			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon">
		</div>
		<div class="row">
			<div class="col-2">
				<h1>Give Your Workout<br> A New Style!</h1>
				<p> Success isn't always about greatness. It's about consistency.<br> Consistent work hard gains success. Greatness will come.</p>
				<a href="{{route('Shop')}}" class="btn">EXPLORE NOW &#8594;</a> 
			</div>
			<div class="col-2">
				<img src="images/image1.png">
			</div>
		</div>
	</div>
<!----- offer ------>
		<div class="offer">
			<div class="small-container">
				<div class="row">
					<div class ="col-2">
						<img src="images/puma8.png" class="offer-img">
					</div>
					<div class="col-2">
						<p>Exclusively Available on REDSTORE</p>
						<h1>PUMA Bull Gibe</h1>
						<small>Women's shoe, standard with size, 
						every shoe size is availabe, RARE product!<br></small>
						<a href="viewShoes.php?category=Woman" class="btn">Quickly Find it OUT! &#8594</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
		
@include('footer')

</body>
</html>