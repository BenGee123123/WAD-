<!--php
$servername = 'localhost';
$dbName = 'assignment';
$dbUserName = 'root';
$password = '';

$mysqli = mysqli_connect($servername, $dbUserName, $password, $dbName);
$resultFeature = mysqli_query($mysqli, "SELECT * FROM shoes WHERE isFeatured = '1'");
$resultLastest = mysqli_query($mysqli, "SELECT * FROM shoes ORDER BY date DESC");

?>-->
<html>
	<head>
	<meta charset="UTF-8">
	<title>ALL Products - RedStore</title>
	<link href="<?php echo e(asset('css/styleshop.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<?php echo $__env->make('shopheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- new navigation -->
		<div class="categories">
			<div class="small-container">
			<div class="row">
				<div class="col-3">
					<img src="images/gallery-2.jpg">
					<button type="button" class = 'btn'><a href = 'viewShoes.php?category=Man'>Man</a></button>
					
				</div>
				<div class="col-3">
					<img src="images/category-3.jpg">
					<button type="button" class = 'btn'><a href = 'viewShoes.php?category=Woman'>Woman</a></button>
				</div>
				<div class="col-3">
					<img src="images/kidcategory.png">
					<button type="button" class = 'btn'><a href = 'viewShoes.php?category=Kids'>Kids</a></button>
				</div>
				
			</div>
			<div class="row">
				<div class="col-3">
						<a href = "<?php echo e(route('viewShoes')); ?>" class = 'btn'>View All Shoes</a>
				</div>
			</div>
			</div>
					
		</div>

		<!--  end new navigation -->
	
		<div class="small-container">
			<h2 class="title">Featured Products</h2>
			<div class="row">
				<!--?php 
				while($row = mysqli_fetch_array($resultFeature))
				{
					echo "<div class='col-4'>";
					echo '<br/><img src="data:image/png;base64,'.base64_encode($row['shoeIMG']).'"/>';
					echo "<h4>".$row['name']."</h4>";
					echo "<div class='rating'>";
					$stars = 0;
					for($i = 0; $i < 5; $i++)
					{
						if($i < $row['rating'])
						{
							echo "<i class='fa fa-star'></i>";
							$stars++;
						}							
						else
						{
							echo "<i class='fa fa-star-o'></i>";
							$stars++;
						}
					}
					echo "<a href = 'item.php?id=".$row['shoeId']."' class = 'btn'>Details</a>";
					echo "</div>";
					echo '<p>RM'.$row['price'];
					if($row['discount'] > 0)
					{
						echo " Discount : ". $row['discount']."%";
					}
					echo '</p>';
					echo "</div>";
				}
				?>-->
			</div>
			
			<!----- Latest Products -------->
			<h2 class="title">Latest Products</h2>
			<div class="row">
			<!--?php 
				$j = 0;
				while($row = mysqli_fetch_array($resultLastest))
				{
					echo "<div class='col-4'>";
					echo '<br/><img src="data:image/png;base64,'.base64_encode($row['shoeIMG']).'"/>';
					echo "<h4>".$row['name']."</h4>";
					echo "<div class='rating'>";
					$stars = 0;
					for($i = 0; $i < 5; $i++)
					{
						if($i < $row['rating'])
						{
							echo "<i class='fa fa-star'></i>";
							$stars++;
						}							
						else
						{
							echo "<i class='fa fa-star-o'></i>";
							$stars++;
						}
					}
					echo "<a href = 'item.php?id=".$row['shoeId']."' class = 'btn'>Details</a>";
					echo "</div>";
					echo '<p>RM'.$row['price'];
					if($row['discount'] > 0)
					{
						echo " Discount : ". $row['discount']."%";
					}
					echo '</p>';
					echo "</div>";
					$j += 1;
					if($j > 3)
						break;
				}
				?>-->
			</div>
		</div>
	</body>
</html>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\benge\WAD\TestingStore\resources\views//Shop.blade.php ENDPATH**/ ?>