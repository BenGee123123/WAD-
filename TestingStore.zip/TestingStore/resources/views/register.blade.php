<!--?php include ('connectdb.php') ?-->

<html>
<head>
 <title>Registration for new user</title>
 <link rel = "stylesheet" type = "text/css" href = "{{ asset('css/loginstyle.css') }}">
<link href="{{ asset('css/styleshop.css') }}" rel="stylesheet">
</head>

<body >
  <div class="registerpage" >
<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<img src="images/logo.png" width="175px">
			</div>
			<nav>
				<ul>
					<li><a href="{{route('MainPage')}}">Home</a></li>
					<li><a href="{{route('Shop')}}">Shop</a></li>
					<li><a href="{{route('Blog')}}">Blog</a></li>
					<li><a href="{{route('FAQ')}}">FAQ</a></li>
					<li><a href="{{route('About')}}">About</a></li>
					<li><a href="{{route('Contact')}}">Contact</a></li>
					<li><a href="{{route('login')}}" id="a">Log In</a></li>
				</ul>
			</nav>
				<!--
				<script>
				
				var x = "<php echo $_SESSION['success']; ?>";
				if (x != "Logged In"){
				document.getElementById("a").href="login.php";
				document.getElementById("a").textContent="Log In"
				}
				else{
				document.getElementById("a").href="logout.php";
				document.getElementById("a").textContent="Log Out"
				}
				</script>
			-->
				
			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon">
		</div>

	</div>
	</div>
  <div class = "loginheader">
	<h2>Register New Member</h2>
  </div>


  <form method = "post" action = "register.php">
	<!--?php include ('errors.php'); ?-->

	<div class = "input-group">
	  <label>Username:</label>
	  <input type = "text" name = "username" value = "">
	</div>

	<div class = "input-group">
	  <label>Email:</label>
	  <input type = "email" name = "email" value = "">
	</div>

	<div class = "input-group">
	  <label>Password:</label>
	  <input type = "password" name = "password_1">
	</div>
 
	<div class = "input-group">
	  <label>Confirm Password:</label>
	  <input type = "password" name = "password_2">
	</div>

	<div class = "input-group">
	  <button type = "submit" class = "loginbtn" name = "reg_user">Register</button>
	</div>
	
	<p>
	  Already a member? <a class="register" href = "{{route('login')}}">Log in</a>
	</p>
	<div>

	</div>

  </form>
  </div>
  
</body>

</html>
<div>
@include('footer')
</div>