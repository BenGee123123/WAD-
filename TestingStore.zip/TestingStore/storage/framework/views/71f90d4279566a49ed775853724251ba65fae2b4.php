<!--?php

$servername = 'localhost';
$dbName = 'assignment';
$dbUserName = 'root';
$password = '';
$mysqli = mysqli_connect($servername, $dbUserName, $password, $dbName);
if(isset($_POST['filtersortby']))
{
	$brand = $_POST['brand'];
	$type = $_POST['type'];
	$sort = $_POST['sort'];
	$category = $_POST['category'];
	$stmt = "SELECT * FROM shoes ";

	if($brand != 'none' && $type != 'none' && $category != 'none')
		$stmt .= "WHERE brand = '$brand' AND type = '$type' AND category = '$category'";
	else
	{
		if($brand == 'none')
		{
			if($type == 'none')
			{
				if($category != 'none')
				{
                    $stmt .= "WHERE category = '$category' ";
				}
			}
			else
			{
				if($category == 'none')
				{
					$stmt .= "WHERE type = '$type' ";
				}
				else
				{
					$stmt .= "WHERE type = '$type' AND category = '$category' ";
				}	
			}	
		}
		else
		{
			if($type == 'none')
			{
				if($category == 'none')
				{
					$stmt .= "WHERE brand = '$brand' ";
				}
				else
				{
					$stmt .= "WHERE brand = '$brand' AND category = '$category' ";
				}	
			}
			else
			{
				if($category == 'none')
				{
					$stmt .= "WHERE brand = '$brand' AND type = '$type' ";
				}
			}
		}
	}
	switch($sort)
	{
	case 'none':
		break;
	case 'low':
		$stmt .= "ORDER BY price";
		break;
	case 'high':
		$stmt .= "ORDER BY price DESC";
		break;
	case 'latest':
		$stmt .= "ORDER BY date DESC";
		break;
	case 'discount':
		$stmt .= "ORDER BY discount DESC";
		break;
	}
}
else
{
	$category = $_GET['category'];
	if($category != 'none')
		$stmt = "SELECT * FROM shoes WHERE category = '$category'";
	else
	{
		$stmt = "SELECT * FROM shoes";
	}	
}

$result = mysqli_query($mysqli, $stmt);
?-->
<!--?php session_start(); ?-->
<html>
	<head>
	<meta charset="UTF-8">
	<title>ALL Products - RedStore</title>
	<link rel="stylesheet" href="styleshop.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
	<div class="header">
		<div class="container">
			<div class="navbar">
				<div class="logo">
					<img src="images/logo.png" width="175px">
				</div>
				<nav>
					<ul>
					<li><a href="<?php echo e(route('MainPage')); ?>">Home</a></li>
					<li><a href="<?php echo e(route('Shop')); ?>">Shop</a></li>
					<li><a href="<?php echo e(route('Blog')); ?>">Blog</a></li>
					<li><a href="<?php echo e(route('FAQ')); ?>">FAQ</a></li>
					<li><a href="<?php echo e(route('About')); ?>">About</a></li>
					<li><a href="<?php echo e(route('Contact')); ?>">Contact</a></li>
					<li><a href="<?php echo e(route('login')); ?>" id="a">Log In</a></li>
					</ul>
				</nav>
				<img src="images/cart.png" width="30px" height="30px">
				<img src="images/menu.png" class="menu-icon">
			</div>
			<div class="row">
				<div class="col-2">
				</div>
				<div class="col-2">
					<img src="images/image1.png">
				</div>
			</div>
		</div>
	</div>
	<form name = 'filterSort' method = 'post' action = "viewShoes.php">
		<!-- new navigation -->
		<div class="categories">
			<div class="small-container">
			<div class="row">
				<div class="col-3">
					<img src="images/gallery-2.jpg">
					<button type="button" class = 'btn'><a href = 'viewShoes.php?category=Man'>Man</a></button>
					
				</div>
				<div class="col-3">
					<img src="images/category-3.jpg">
					<button type="button" class = 'btn'><a href = 'viewShoes.php?category=Woman'>Woman</a></button>
				</div>
				<div class="col-3">
					<img src="images/kidcategory.png">
					<button type="button" class = 'btn'><a href = 'viewShoes.php?category=Kids'>Kids</a></button>
				</div>
			</div>
			<div class="row">
				<div class="col-3">
					<a href = "<?php echo e(route('viewShoes')); ?>" class = 'btn'>View All Shoes</a>
				</div>
			</div>
			</div>
		</div>
		
		<!--  end new navigation -->
		<div class="row">
			<h2>All Products</h2>
				<!--?php 
					echo "<select name = 'brand'>";
					switch($brand)
					{
					case 'Nike':
						echo "<option value = 'Nike'>Nike</option>";
						echo "<option value = 'none'>Select Brand</option>";
						echo "<option value = 'Adidas'>Adidas</option>";
						echo "<option value = 'Puma'>Puma</option>";
						break;
					case 'Adidas':
						echo "<option value = 'Adidas'>Adidas</option>";
						echo "<option value = 'none'>Select Brand</option>";
						echo "<option value = 'Nike'>Nike</option>";
						echo "<option value = 'Puma'>Puma</option>";
						break;
					case 'puma':
						echo "<option value = 'Puma'>Puma</option>";
						echo "<option value = 'none'>Select Brand</option>";
						echo "<option value = 'Nike'>Nike</option>";
						echo "<option value = 'Adidas'>Adidas</option>";
						break;
					case 'none':
					case '':
						echo "<option value = 'none'>Select Brand</option>";
						echo "<option value = 'Nike'>Nike</option>";
						echo "<option value = 'Adidas'>Adidas</option>";
						echo "<option value = 'Puma'>Puma</option>";
						break;
					}
					echo "</select>";
				?-->
				<!--?php 
					echo "<select name = 'type'>";
					switch($type)
					{
					case 'Casual':
						echo "<option value = 'Casual'>Casual</option>";
						echo "<option value = 'none'>Select Category</option>";
						echo "<option value = 'Running'>Running</option>";
						echo "<option value = 'Training'>Training</option>";
						echo "<option value = 'Golf'>Golf</option>";
						break;
					case 'Running':
						echo "<option value = 'Running'>Running</option>";
						echo "<option value = 'none'>Select Category</option>";
						echo "<option value = 'Casual'>Casual</option>";
						echo "<option value = 'Training'>Training</option>";
						echo "<option value = 'Golf'>Golf</option>";
						break;
					case 'Training':
						echo "<option value = 'Training'>Training</option>";
						echo "<option value = 'none'>Select Category</option>";
						echo "<option value = 'Casual'>Casual</option>";
						echo "<option value = 'Running'>Running</option>";
						echo "<option value = 'Golf'>Golf</option>";
						break;
					case 'Golf':
						echo "<option value = 'Golf'>Golf</option>";
						echo "<option value = 'none'>Select Category</option>";
						echo "<option value = 'Casual'>Casual</option>";
						echo "<option value = 'Running'>Running</option>";
						echo "<option value = 'Training'>Training</option>";
						break;
					case 'none':
					case '':
						echo "<option value = 'none'>Select Category</option>";
						echo "<option value = 'Casual'>Casual</option>";
						echo "<option value = 'Running'>Running</option>";
						echo "<option value = 'Training'>Training</option>";
						echo "<option value = 'Golf'>Golf</option>";
						break;
					}
					echo "</select>";
				?-->
				<!--?php 
					echo "<select name = 'sort'>";
					switch($sort)
					{
					case 'low':
						echo "<option value = 'low'>Sort by lowest price</option>";
						echo "<option value = 'none'>Sort By</option>";
						echo "<option value = 'high'>Sort by highest price</option>";
						echo "<option value = 'latest'>Latest model</option>";
						echo "<option value = 'discount'>Highest Discount</option>";
						break;
					case 'high':
						echo "<option value = 'high'>Sort by highest price</option>";
						echo "<option value = 'none'>Sort By</option>";
						echo "<option value = 'low'>Sort by lowest price</option>";
						echo "<option value = 'latest'>Latest model</option>";
						echo "<option value = 'discount'>Highest Discount</option>";
						break;
					case 'latest':
						echo "<option value = 'latest'>Latest model</option>";
						echo "<option value = 'none'>Sort By</option>";
						echo "<option value = 'low'>Sort by lowest price</option>";
						echo "<option value = 'high'>Sort by highest price</option>";
						echo "<option value = 'discount'>Highest Discount</option>";
						break;
					case 'discount':
						echo "<option value = 'discount'>Highest Discount</option>";
						echo "<option value = 'none'>Sort By</option>";
						echo "<option value = 'low'>Sort by lowest price</option>";
						echo "<option value = 'high'>Sort by highest price</option>";
						echo "<option value = 'latest'>Latest model</option>";
						break;
					case 'none':
					case '':
						echo "<option value = 'none'>Sort By</option>";
						echo "<option value = 'low'>Sort by lowest price</option>";
						echo "<option value = 'high'>Sort by highest price</option>";
						echo "<option value = 'latest'>Latest model</option>";
						echo "<option value = 'discount'>Highest Discount</option>";
						break;
					}
					echo "</select>";
				?-->
				<input type = submit name = 'filtersortby' class="sort" value = "Sort by">
				<input type = "hidden" name= "category" value= <php echo $category; ?> >
			</form>
		</div>

	<div class="small-container">			
			<!----- Latest Products -------->
			<div class="row">
			<!--?php 
				while($row = mysqli_fetch_array($result))
				{
					echo "<div class='col-4'>";
					echo '<br/><img src="data:image/png;base64,'.base64_encode($row['shoeIMG']).'"/>';
					echo "<h4>".$row['name']."</h4>";
					echo "<h4>Category : ".$row['category']."</h4>";
					echo "<h4>Type     : ".$row['type']."</h4>";
					echo "<h4>Date     : ".$row['date']."</h4>";
					echo "<div class='rating'>";
					$stars = 0;
					for($i = 0; $i < 5; $i++)
					{
						if($i < $row['rating'])
						{
							echo "<i class='fa fa-star'></i>";
							$stars++;
						}							
						else
						{
							echo "<i class='fa fa-star-o'></i>";
							$stars++;
						}
					}
					echo "<a href = 'item.php?id=".$row['shoeId']."' class = 'btn'>Details</a>";
					echo "</div>";
					echo '<p>RM'.$row['price'];
					if($row['discount'] > 0)
					{
						echo " Discount : ". $row['discount']."%";
					}
					echo '</p>';
					echo "</div>";
				}
				?-->
			</div>
		</div>
		<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</body>
</html>	

<?php /**PATH C:\Users\benge\WAD\TestingStore\resources\views//viewShoes.blade.php ENDPATH**/ ?>