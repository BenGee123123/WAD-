<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('MainPage');
})->name('MainPage');

Route::get('/About', [PageController::class, 'About'])->name('About');
Route::get('/FAQ', [PageController::class, 'FAQ'])->name('FAQ');
Route::get('/Shop', [PageController::class, 'Shop'])->name('Shop');
Route::get('/Blog', [PageController::class, 'Blog'])->name('Blog');
Route::get('/Contact', [PageController::class, 'Contact'])->name('Contact');
Route::get('/login', [PageController::class, 'login'])->name('login');
Route::get('/register', [PageController::class, 'register'])->name('register');
Route::get('/createBlog', [PageController::class, 'createBlog'])->name('createBlog');
Route::get('/viewShoes', [PageController::class, 'viewShoes'])->name('viewShoes');
//Route::get('/MainPage', [PageController::class, 'MainPage'])-> name('MainPage');

