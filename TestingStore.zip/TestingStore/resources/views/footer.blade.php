<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link href="{{ asset('css/styleshop.css') }}" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>	   
	   <div class="footer">
			<div class="container">
				<div class="row">
					<div class="footer-col-2">
						<img src="images/logo-white.png">
						<p>Our purpose Is to Sustainably make the Pleasure and Benefits of Sports Accessible to the Many.</p>
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-twitter"></a>
						<a href="#" class="fa fa-instagram"></a>
						<p>Copyright 2021 - University Tunku Abdul Rahman Sg Long</p>
					</div>
				</div>
			</div>
		</div>


</body>
</head>