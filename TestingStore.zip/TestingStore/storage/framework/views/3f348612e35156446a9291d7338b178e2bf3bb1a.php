
<html>

<head>
<title>FAQs</title>
</head>
<link href="<?php echo e(asset('css/styleshop.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

/* searchbar*/

.TypeHeader
{
	margin: 25px 25px 0 0;
	padding: 25px 0;
}
.searchBar{
    margin: auto;
    overflow: hidden;
    padding: 10px;
    background-color: #e9e9e9;
    text-align: center;
}

.searchBar input[type=text]{
  padding: 15px;
  font-size: 17px;
  border: none;
  float: left;
  width: 90%;
  background: white;
}

.searchBar input[type=text]:hover{
  background: #ccc;
}

.searchBar button{
  float: right;
  width: 7%;
  padding: 15px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.searchBar button:hover{
  background: #bbb;
}

/* sidebar */
.sideBar{
  width: 160px;
  position: fixed;
  top: 150px;
  left: 8px;
  background-color: #e7d5ff;
  overflow-x: hidden;
  padding-top: 10px;
  border-radius: 13px;
}

.sideBar a{
  padding: 5px 5px 6px 15px;
  text-decoration: none;
  font-size: 25px;
  color: black;
  display: block;
}

.sideBar a:hover{
  background-color: #555;
  color: white;
}

.main {
  margin-left: 160px; /* Same as the width of the sidebar */
  padding: 20px 60px 200px 60px;
}

/* accordian */
.accordion {
  background-color: #212838;
  color: rgba(255,255,255,.6);
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.7s;
  border-radius: 20px;
}

.active, .accordion:hover {
  background-color: #ccc; 
}

.panel {
  padding: 0 18px;
  display: none;
  background-color: #212853;
  overflow: hidden;
  border-radius: 20px;
}

.panel p
{
	color: rgba(255,255,255,.6);
	padding: 2rem;
	font-size: 1.4rem;
}

.faqbackground
{
	background: radial-gradient(#fff,#ffd6d6);
}

.faqheader
{
	text-align:center;
	margin: auto;
	font-weight: bold;
}

.fa.fa-plus
{
	color: #8fc460;
	
}
</style>

<body>

<?php echo $__env->make('mainpageheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class = "faqbackground">
	<h2 class="faqheader">FREQUENTLY ASKED QUESTIONS</h2>
<div class = "sideBar"> 
  
  <a href="#account">Account</a>
  <a href="#order">Order and Payment</a>
  <a href="#delivery">Delivery</a>
</div>

<div class = "main">

<!--php 
				$i = 0;
				
				while($row = mysqli_fetch_array($Account))
				{
					if($i<1)
					{
						echo "<h2 id = 'account' class='TypeHeader'>".$row['Qtype']."</h2>";
						$i = $i+1;
					}

					echo "<button class='accordion'>".$row['question']."".""."".""."<i class='fa fa-plus'></i> </button>";
					echo "<div class='panel'><p style='font-size:120%;'>".$row['answer']."</p></div>";
				}
				
				$i = 0;
				while($row = mysqli_fetch_array($OrderAndPayment))
				{
					if($i<1)
					{
						echo "<h2 id = 'order' class='TypeHeader'>".$row['Qtype']."</h2>";
						$i = $i+1;
					}
					echo "<button class='accordion'>".$row['question']."".""."".""."<i class='fa fa-plus'></i> </button>";
					echo "<div class='panel'><p style='font-size:120%;'>".$row['answer']."</p></div>";
				}
				
				$i = 0;
				while($row = mysqli_fetch_array($Delivery))
				{
					if($i<1)
					{
						echo "<h2 id = 'delivery' class='TypeHeader'>".$row['Qtype']."</h2>";
						$i = $i+1;
					}
					echo "<button class='accordion'>".$row['question']."".""."".""."<i class='fa fa-plus'></i> </button>";
					echo "<div class='panel'><p style='font-size:120%;'>".$row['answer']."</p></div>";
				}
?> -->

</div>
</div>
<div class="foot">

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!--javascript for accordian -->
<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
</script>

</div>

</body>

</html><?php /**PATH C:\Users\benge\WAD\TestingStore\resources\views//FAQ.blade.php ENDPATH**/ ?>