<!--?php include ('connectdb.php') ?-->

<html>
<head>
  <title>LogIn page</title>
  <link rel = "stylesheet" type = "text/css" href = "{{ asset('css/loginstyle.css') }}">
  <link href="{{ asset('css/styleshop.css') }}" rel="stylesheet">
</head>

<body>
  <div class="loginpage">
  
<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<img src="images/logo.png" width="175px">
			</div>
			<nav>
				<ul>
					<li><a href="{{route('MainPage')}}">Home</a></li>
					<li><a href="{{route('Shop')}}">Shop</a></li>
					<li><a href="{{route('Blog')}}">Blog</a></li>
					<li><a href="{{route('FAQ')}}">FAQ</a></li>
					<li><a href="{{route('About')}}">About</a></li>
					<li><a href="{{route('Contact')}}">Contact</a></li>
					<li><a href="{{route('login')}}" id="a">Log In</a></li>
				</ul>
			</nav>
				
			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon">
		</div>

	</div>
	</div>
	
	
  <div class = "loginheader">
    <h2>Log In</h2>
  </div>
  
  <form method = "post" action = "login.php">
	<!--?php include ('errors.php'); ?-->

	<div class = "input-group">
	  <label>Username:</label>
	  <input type = "text" name = "username" >
	</div>

	<div class = "input-group">
	  <label>Password:</label>
	  <input type = "password" name = "password" >
	</div>

	<div class = "input-group">
	  <button type = "submit" class = "loginbtn" name = "login_user">Log In</button>
	</div>

	<p>
	  Not a member? <a class="register" href = "{{route('register')}}">Sign up</a>
	</p>

  </form>

</div>

<div>
@include('footer')
</div>
</body>

</html>
