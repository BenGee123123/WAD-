<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function About() {
        
        return view('/About');
    }

    public function FAQ() {
        return view('/FAQ');
    }

    public function Shop() {
        return view('/Shop');
    }

    public function Blog() {
        return view('/Blog');
    }

    public function Contact() {
        return view('/Contact');
    }

    public function login() {
        return view('/login');
    }

    public function register() {
        return view('/register');
    }

    public function createBlog() {
        return view('/createBlog');
    }
    
    public function viewShoes() {
        return view('/viewShoes');
    }

}
