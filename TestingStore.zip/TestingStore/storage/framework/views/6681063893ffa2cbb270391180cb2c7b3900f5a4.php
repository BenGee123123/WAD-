<!--?php session_start(); ?-->
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="UTF-8">
  <title>CONTACT US</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo e(asset('css/styleMY.css')); ?>">
  <link href="<?php echo e(asset('css/styleshop.css')); ?>" rel="stylesheet">
</head>

<body>

<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<img src="images/logo.png" width="175px">
			</div>
			<nav>
				<ul>
					<li><a href="<?php echo e(route('MainPage')); ?>">Home</a></li>
					<li><a href="<?php echo e(route('Shop')); ?>">Shop</a></li>
					<li><a href="<?php echo e(route('Blog')); ?>">Blog</a></li>
					<li><a href="<?php echo e(route('FAQ')); ?>">FAQ</a></li>
					<li><a href="<?php echo e(route('About')); ?>">About</a></li>
					<li><a href="<?php echo e(route('Contact')); ?>">Contact</a></li>
					<li><a href="<?php echo e(route('login')); ?>" id="a">Log In</a></li>
				</ul>
			</nav>
				<!--
				<script>
				
				var x = "<php echo $_SESSION['success']; ?>";
				if (x != "Logged In"){
				document.getElementById("a").href="login.php";
				document.getElementById("a").textContent="Log In"
				}
				else{
				document.getElementById("a").href="logout.php";
				document.getElementById("a").textContent="Log Out"
				}
				</script>
				-->
			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon">
		</div>

	</div>
	</div>


<section class="contact">
		<div class="content">
			<h2>CONTACT US</h2>
			<p></p>
		</div>
		<div class="container5">
			<div class="contactInfo">
				<div class="box">
					<div class="icon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
					<div class="text">
					    <h3>Address</h3>
					    <p>UTAR<br>Jalan Sungai Long, <br>Bandar Sungai Long, <br>43000 Kajang, <br>Selangor</p>
					</div>
				<br></br>
				<br></br>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
					<div class="text">
					    <h3>Phone</h3>
					    <p>016 2 512 0909</p>
					    <p>016 2 512 3215</p>
					</div>
				<br></br>
				<br></br>
				</div>
				<div class="box">
					<div class="icon"><i class="fa fa-envelope" aria-hidden="true"></i></div>
					<div class="text">
					    <h3>Email</h3>
					    <p>redstore@redstore.com</p>

					</div>
				</div>
			</div>
			<div class="contactForm">
				<form action="readContactus.php" method ="post">
					<h2>Send Message</h2>
					<div class="inputBox">
						<input type="text" name="name" required="required">
						<span>Full Name</span>
					</div>
					<br></br>
					<div class="inputBox">
						<input type="text" name="email" required="required">
						<span>Email</span>
					</div>
					<br></br>
					<div class="inputBox">
						<textarea name="message" required="required"></textarea>
						<span>Type your message... </span>
					</div>
					<br></br>
					<div class="inputBox">
						<input type="submit" name="contact-submit" value="Send">
					</div>
				</form>
			</div>
		</div>
	</section>

		

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		



</body>
</html><?php /**PATH C:\Users\benge\WAD\TestingStore\resources\views//Contact.blade.php ENDPATH**/ ?>