<!--?php session_start(); ?-->
<html>
<div class="header">
		<div class="container">
			<div class="navbar">
				<div class="logo">
					<img src="images/logo.png" width="175px">
				</div>
				<nav>
					<ul>
						<li><a href="<?php echo e(route('MainPage')); ?>">Home</a></li>
						<li><a href="<?php echo e(route('Shop')); ?>">Shop</a></li>
						<li><a href="<?php echo e(route('Blog')); ?>">Blog</a></li>
						<li><a href="<?php echo e(route('FAQ')); ?>">FAQ</a></li>
						<li><a href="<?php echo e(route('About')); ?>">About</a></li>
						<li><a href="<?php echo e(route('Contact')); ?>">Contact</a></li>
						<li><a href="<?php echo e(route('login')); ?>" id="a">Log In</a></li>
					</ul>
				</nav>
				
				<!--<script>
				
				var x = "<php echo $_SESSION['success'];?>";
				if (x != "Logged In"){
				document.getElementById("a").href="login.php";
				document.getElementById("a").textContent="Log In"
				}
				else{
				document.getElementById("a").href="logout.php";
				document.getElementById("a").textContent="Log Out"
				}
				
				</script> -->
				
				
				
				<img src="images/cart.png" width="30px" height="30px">
				<img src="images/menu.png" class="menu-icon">
			</div>
			<div class="row">
				<div class="col-2">
					<h1>SHOPPING<br> Look For A New Style!</h1>
				</div>
				<div class="col-2">
					<img src="images/image1.png">
				</div>
			</div>
		</div>
	</div>
<html><?php /**PATH C:\Users\benge\WAD\TestingStore\resources\views/shopheader.blade.php ENDPATH**/ ?>