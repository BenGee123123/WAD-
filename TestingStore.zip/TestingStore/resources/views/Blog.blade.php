<!--?php

include "blogdata.php";
?-->
<!--?php session_start(); ?-->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>JETSPORT | Just Dont Do It</title>
	<link href="{{ asset('css/styleshop.css') }}" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	
	<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<img src="images/logo.png" width="175px">
			</div>
			<nav>
				<ul>
					<li><a href="{{route('MainPage')}}">Home</a></li>
					<li><a href="{{route('Shop')}}">Shop</a></li>
					<li><a href="{{route('Blog')}}">Blog</a></li>
					<li><a href="{{route('FAQ')}}">FAQ</a></li>
					<li><a href="{{route('About')}}">About</a></li>
					<li><a href="{{route('Contact')}}">Contact</a></li>
					<li><a href="{{route('login')}}" id="a">Log In</a></li>
				</ul>
			</nav>
				<!--
				<script>
				
				var x = "<php echo $_SESSION['success']; ?>";
				if (x != "Logged In"){
				document.getElementById("a").href="login.php";
				document.getElementById("a").textContent="Log In"
				}
				else{
				document.getElementById("a").href="logout.php";
				document.getElementById("a").textContent="Log Out"
				}
				</script>
				-->
			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon">
		</div>
				<!--?php if(isset($_POST['blogadded']))
				{
					if($_POST['blogadded'] == "successful")
					
					echo "Blog successfully added!";
					
				}
				?-->
		<div class="row">
			<div class="col-2">
				<h1>BLOGS ABOUT SHOES</h1>
				<p> FEEL FREE TO GIVE YOUR FEEDBACK THROUGH THE BLOGS!</p>
				<a href="{{route('createBlog')}}" class="btn">+ Create a new post</a>
			</div>
		</div>
	<div class="blogs">
		<div class="small-container">
			<div class="row">
				

				
				
				<!--?php foreach($query as $q){?>
				
					<div class="col-3">
					<i class="fa fa-quote-left"></i>
					<p><php echo $q['topic'];?></p>
					<h3>?php echo $q['name'];?></h3>
					<p><php echo $q['date'];?></p>
					<a href="viewblog.php?id=<php echo $q['blogId']?>" class="btn">Read More Details</a>
					</div>
				
				<php }?-->
				
			</div>
			
		</div>
	</div>
	</div>

	@include ('footer')

	</div>
	

</body>
</html>