<!--?php 

session_start();

if($_SESSION['success'] != "Logged In"){
	header('location: login.php');
}

include ('blogdata.php') 

?-->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>JETSPORT | Just Dont Do It</title>
	<link href="{{ asset('css/styleshop.css') }}" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	
	<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<img src="images/logo.png" width="175px">
			</div>
			<nav>
				<ul>
					<li><a href="{{route('MainPage')}}">Home</a></li>
					<li><a href="{{route('Shop')}}">Shop</a></li>
					<li><a href="{{route('Blog')}}">Blog</a></li>
					<li><a href="{{route('FAQ')}}">FAQ</a></li>
					<li><a href="{{route('About')}}">About</a></li>
					<li><a href="{{route('Contact')}}">Contact</a></li>
					<li><a href="{{route('login')}}" id="a">Log In</a></li>
				</ul>
			</nav>

				<script>
				
				var x = "<php echo $_SESSION['success']; ?>";
				if (x != "Logged In"){
				document.getElementById("a").href="login.php";
				document.getElementById("a").textContent="Log In"
				}
				else{
				document.getElementById("a").href="logout.php";
				document.getElementById("a").textContent="Log Out"
				}
				</script>

			<img src="images/cart.png" width="30px" height="30px">
		</div>
		<div class="row">
			<div class="col-2">
				<h1>WHAT'S ON YOUR MIND?</h1>
				<p> SHARE ANYTHING YOU DESIRE!</p>
			</div>
		</div>
	<div class="blogs">
		<div class="small-container">
			<div class="row">
				<div class="col-4">
					<form method="POST">
						<div class="createtitle">Name</div> 
						<div>
						<input type="text" name="name"  class="form1">
						</div>
						<div class="createtitle">Topic</div>
						<div>
						<input type="text" name="topic" class="form1">
						</div>
						<div class="createtitle">Introduction</div>
						<div>
						<textarea name="intro" class="form"></textarea>
						</div>
						<div class="createtitle">Content</div>
						<div>
						<textarea name="content" class="form"></textarea>
						</div>
						<div class="createtitle">Conclusion</div>
						<div>
						<textarea name="conclusion" class="form"></textarea>
						</div>
						<button name="new_post" class="btnAdd">Add Post</button>
					</form>
					
					
				</div>
					
				
			</div>
		</div>
	</div>
	</div>
	</div>


	@include ('footer')

</body>
</html>



<!--?php
	$servername = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'OLMS';
	

		$conn = mysqli_connect($servername,$username,$password,$dbname );
if(!$conn)
{
	echo "<h3>Not able to establish Database connection</h3>";
}
		if(isset($_POST['book-submit']))
		{
		$bookName = $_POST['bookname'];
		$authorName = $_POST['authorname'];
		$year = $_POST['bookyear'];
		$quantity = $_POST['quantity'];
		
		$result = mysqli_query($mysqli,"INSERT INTO books (bookname, authorname, bookyear, quantity, AvailableQty, BarrowedQty) VALUES
		('$bookName', '$authorName', '$year', '$quantity', '$quantity', '0')");
		if(result == true)
		{
		
		echo "<h2>Your adding has submitted</h2>";
		header("Location: AddBook.html?AddBook=success");
		exit();
		}
		}
?-->