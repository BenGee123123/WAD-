
<html>
<link rel="stylesheet" href="styleshop.css">
<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<img src="images/logo.png" width="175px">
			</div>
			<nav>
				<ul>
					<li><a href="{{route('MainPage')}}">Home</a></li>
					<li><a href="{{route('Shop')}}">Shop</a></li>
					<li><a href="{{route('Blog')}}">Blog</a></li>
					<li><a href="{{route('FAQ')}}">FAQ</a></li>
					<li><a href="{{route('About')}}">About</a></li>
					<li><a href="{{route('Contact')}}">Contact</a></li>
					<li><a href="{{route('login')}}" id="a">Log In</a></li>
				</ul>
			</nav>
			
			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon">
		</div>

	</div>
	</div>
</html>