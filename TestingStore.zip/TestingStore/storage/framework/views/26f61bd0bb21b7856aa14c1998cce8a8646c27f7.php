<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="UTF-8">
  <title>ABOUT US</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo e(asset('css/styleMY.css')); ?>">
  <link href="<?php echo e(asset('css/styleshop.css')); ?>" rel="stylesheet">
</head>

<body>
<div class="header">
<?php echo $__env->make('mainpageheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



	<div class="banner">
	  <header>
	   <div class="toggle"></div>
	  </header>
	 <img src="images/aboutus.jpg">
	 <div class="content">
	  <h4>Success By RedStore</h4>
	  <p>No Decison Should Be Made on An Empy Shopping Bag</p>
	  <p>Donita K.Paul</p>
	 </div>
	</div>


 <section class="aboutus">
  <div class="content1">
   <h4 class="heading">Our Purpose</h4>
	<p class="text1">We believe in the transformative power of technology and want to change the world for the better by providing a platform to connect buyers and sellers within one community.</p> <br><br>

   <h4 class="heading">Our Positioning</h4>
<p class="text1">To Internet users across the region, RedStore offers a one-stop online shopping experience that provides a wide selection of products, a social community for exploration, and seamless fulfilment services.</p>
<br><br>
  
  <h4 class="heading">Our Personality</h4>
<p class="text1">To define who we are - how we talk, behave or react to any given situation - in essence, we are Simple, Happy and Together. These key attributes are visible at every step of the RedStore journey.</p>

<br><br>


<h4 class="heading">STORIES, STYLES AND SPORTSWEAR AT REDSTORE SINCE 2021</h4>
<p class="text1">
Sport keeps us fit. Keeps you mindful. Brings us together. Through sport we have the power to change lives. Whether it is through stories of inspiring athletes. Helping you to get up and get moving. Sportswear featuring the latest technologies, to up your performance. RedStore offers a home to the runner, the basketball player, the soccer kid, the fitness enthusiast. The weekend hiker that loves to escape the city. The yoga teacher that spreads the moves. The 3-Stripes are seen in the music scene. On stage, at festivals. Our sports clothing keeps you focused before that whistle blows. During the race. And at the finish lines. We�re here to supportcreators. Improve their game. Their lives. And change the world.
<br><br>

RedStore is about more than sportswear and workout clothes. We partner with the best in the industry to co-create. This way we offer our fans the sports apparel and style that match their athletic needs, while keeping sustainability in mind. We�re here to support creators. Improve their game. Create change. And we think about the impact we have on our world</p> 
<br><br>



  </div>
  <div class="imgPe">
  <img src="images/window.jpg">
  </div>
	
 </section>
		

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	

</body>
</html><?php /**PATH C:\Users\benge\WAD\TestingStore\resources\views//About.blade.php ENDPATH**/ ?>